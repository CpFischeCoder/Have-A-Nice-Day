# Have-A-Nice-Day-Program
This program will have an irule varible. If you can not run the irule varible there will be a non irule varible. Run the irule have-a-nice-day.vbs first then run the
non irule .vbs script if the irule vbs script does not work.
